# ygnetayushiu.com

This is the official website package for ygnetayushiu.com.

## Contents
- index.html - The main website file
- favicon.ico - Website favicon
- cursor.js - Custom cursor script

## Setup
Simply upload these files to your web hosting service.

## Features
- Custom red text on dark background
- Pentagram cursor with rotation and hover effects
- Interactive cursor animations (rotation, scaling, color changes)
- Responsive design

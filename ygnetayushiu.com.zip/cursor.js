// Custom cursor script for ygnetayushiu.com
document.addEventListener('DOMContentLoaded', function() {
  // Create cursor elements if they don't exist
  if (!document.querySelector('.custom-cursor')) {
    const cursorOuter = document.createElement('div');
    cursorOuter.className = 'custom-cursor';
    document.body.appendChild(cursorOuter);
    
    const cursorDot = document.createElement('div');
    cursorDot.className = 'custom-cursor-dot';
    document.body.appendChild(cursorDot);
    
    // Add cursor styles
    const style = document.createElement('style');
    style.textContent = `
      * {
        cursor: none;
      }
      
      .custom-cursor {
        position: fixed;
        width: 30px;
        height: 30px;
        pointer-events: none;
        z-index: 9999;
        transition: transform 0.2s, opacity 0.3s;
        transform: translate(-50%, -50%);
        clip-path: polygon(50% 0%, 61% 35%, 98% 35%, 68% 57%, 79% 91%, 50% 70%, 21% 91%, 32% 57%, 2% 35%, 39% 35%);
        background-color: rgba(255, 0, 0, 0.7);
      }
      
      .custom-cursor-dot {
        position: fixed;
        width: 4px;
        height: 4px;
        background-color: #ff0000;
        border-radius: 50%;
        transform: translate(-50%, -50%);
        pointer-events: none;
        z-index: 10000;
        transition: opacity 0.3s;
      }
      
      a:hover ~ .custom-cursor {
        width: 45px;
        height: 45px;
        background-color: rgba(255, 0, 0, 1);
        transform: translate(-50%, -50%) rotate(180deg);
      }
    `;
    document.head.appendChild(style);
    
    // Get references to cursor elements
    const cursor = document.querySelector('.custom-cursor');
    const cursorDot = document.querySelector('.custom-cursor-dot');
    
    // Add event listeners
    document.addEventListener('mousemove', e => {
      cursor.style.left = e.clientX + 'px';
      cursor.style.top = e.clientY + 'px';
      
      cursorDot.style.left = e.clientX + 'px';
      cursorDot.style.top = e.clientY + 'px';
    });
    
    // Add pentagram rotation effect
    let rotation = 0;
    window.rotationInterval = setInterval(() => {
      rotation += 1;
      cursor.style.transform = \`translate(-50%, -50%) rotate(\${rotation}deg)\`;
    }, 50);
    
    // Add pulse effect on click
    document.addEventListener('mousedown', () => {
      cursor.style.transform = \`translate(-50%, -50%) rotate(\${rotation}deg) scale(0.8)\`;
      cursor.style.backgroundColor = 'rgba(255, 0, 0, 1)';
    });
    
    document.addEventListener('mouseup', () => {
      cursor.style.transform = \`translate(-50%, -50%) rotate(\${rotation}deg) scale(1)\`;
      cursor.style.backgroundColor = 'rgba(255, 0, 0, 0.7)';
    });
    
    // Add hover effect for links
    const links = document.querySelectorAll('a');
    
    links.forEach(link => {
      link.addEventListener('mouseenter', () => {
        cursor.style.width = '45px';
        cursor.style.height = '45px';
        cursor.style.backgroundColor = 'rgba(255, 0, 0, 1)';
        // Faster rotation on hover
        clearInterval(window.rotationInterval);
        window.rotationInterval = setInterval(() => {
          rotation += 3;
          cursor.style.transform = \`translate(-50%, -50%) rotate(\${rotation}deg)\`;
        }, 30);
      });
      
      link.addEventListener('mouseleave', () => {
        cursor.style.width = '30px';
        cursor.style.height = '30px';
        cursor.style.backgroundColor = 'rgba(255, 0, 0, 0.7)';
        // Resume normal rotation
        clearInterval(window.rotationInterval);
        window.rotationInterval = setInterval(() => {
          rotation += 1;
          cursor.style.transform = \`translate(-50%, -50%) rotate(\${rotation}deg)\`;
        }, 50);
      });
    });
    
    // Hide cursor when leaving the window
    document.addEventListener('mouseout', (e) => {
      if (e.relatedTarget === null) {
        cursor.style.opacity = '0';
        cursorDot.style.opacity = '0';
      }
    });
    
    document.addEventListener('mouseover', () => {
      cursor.style.opacity = '1';
      cursorDot.style.opacity = '1';
    });
  }
});

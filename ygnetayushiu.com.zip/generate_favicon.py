from PIL import Image, ImageDraw, ImageFont
import os

# Create a new image with a transparent background
icon_size = 128
image = Image.new('RGBA', (icon_size, icon_size), (17, 17, 17, 255))
draw = ImageDraw.Draw(image)

# Add text to the image
text = "Y"
text_color = (0, 255, 204, 255)  # #00ffcc in RGBA

# Try to use a system font, or default to a bitmap font
try:
    font = ImageFont.truetype("Arial", 90)  # Adjust size as needed
except IOError:
    font = ImageFont.load_default()

# Calculate text position to center it
text_width, text_height = draw.textbbox((0, 0), text, font=font)[2:4]
position = ((icon_size - text_width) // 2, (icon_size - text_height) // 2 - 10)  # Adjust for visual centering

# Draw the text
draw.text(position, text, font=font, fill=text_color)

# Save as PNG first
image.save('favicon.png')

# Convert to ICO and save
image.save('favicon.ico', format='ICO', sizes=[(16, 16), (32, 32), (48, 48), (64, 64), (128, 128)])

print("Favicon created successfully!")